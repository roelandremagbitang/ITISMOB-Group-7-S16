package com.itismob.s16.mco3.smartexptracker.s16group7itismob

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat

class AddExpenseActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private lateinit var etAmount: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var etDate: EditText
    private lateinit var etNotes: EditText
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button

    private var selectedDateTimestamp: Long = System.currentTimeMillis()
    private val categoryList = mutableListOf("Food", "Transport", "Utilities", "Entertainment", "Others")
    private lateinit var categoryAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_expense)

        etAmount = findViewById(R.id.etAmount)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        etDate = findViewById(R.id.etDate)
        etNotes = findViewById(R.id.etNotes)
        btnSave = findViewById(R.id.btnSaveExpense)
        btnCancel = findViewById(R.id.btnCancelExpense)

        val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.US)
        etDate.setText(sdf.format(Date(selectedDateTimestamp)))

        etDate.setOnClickListener { showDatePicker() }

        categoryAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categoryList)
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = categoryAdapter

        // --- CHECK FOR SCANNER OR BUDGET DATA ---
        val categoryFromBudget = intent.getStringExtra("CATEGORY_FROM_BUDGET")
        if (categoryFromBudget != null) {
            if (!categoryList.any { it.equals(categoryFromBudget, ignoreCase = true) }) {
                categoryList.add(0, categoryFromBudget) // Add to the top of the list
                categoryAdapter.notifyDataSetChanged()
            }
            val position = categoryList.indexOfFirst { it.equals(categoryFromBudget, ignoreCase = true) }
            if (position >= 0) {
                spinnerCategory.setSelection(position)
            }
        } else {
            if (intent.hasExtra("AMOUNT_FROM_SCAN")) {
                val scannedAmount = intent.getDoubleExtra("AMOUNT_FROM_SCAN", 0.0)
                if (scannedAmount > 0) etAmount.setText(scannedAmount.toString())
            }
            if (intent.hasExtra("NOTES_FROM_SCAN")) {
                val scannedNotes = intent.getStringExtra("NOTES_FROM_SCAN")
                etNotes.setText(scannedNotes)
            }
            if (intent.hasExtra("CATEGORY_FROM_SCAN")) {
                val scannedCat = intent.getStringExtra("CATEGORY_FROM_SCAN")
                val position = categoryList.indexOfFirst { it.equals(scannedCat, ignoreCase = true) }
                if (position >= 0) {
                    spinnerCategory.setSelection(position)
                }
            }
        }
        // -------------------------------------

        btnSave.setOnClickListener { saveExpense() }
        btnCancel.setOnClickListener { finish() }
        createNotificationChannel()
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, month, day ->
            calendar.set(year, month, day)
            selectedDateTimestamp = calendar.timeInMillis
            val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.US)
            etDate.setText(sdf.format(calendar.time))
        }

        DatePickerDialog(
            this, dateSetListener,
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun saveExpense() {
        val amountStr = etAmount.text.toString().trim()
        val notes = etNotes.text.toString().trim()
        val category = spinnerCategory.selectedItem?.toString() ?: "Uncategorized"

        if (amountStr.isEmpty()) {
            etAmount.error = "Amount is required"
            return
        }
        val amount = amountStr.toDoubleOrNull()
        if (amount == null) {
            etAmount.error = "Invalid amount"
            return
        }

        val userId = auth.currentUser?.uid
        if (userId == null) {
            Toast.makeText(this, "User not logged in!", Toast.LENGTH_LONG).show()
            return
        }

        val expenseData = hashMapOf(
            "userId" to userId,
            "amount" to amount,
            "category" to category,
            "date" to selectedDateTimestamp,
            "notes" to notes,
            "expenseId" to ""
        )

        db.collection("expenses").add(expenseData).addOnSuccessListener { documentReference ->
            documentReference.update("expenseId", documentReference.id)
            Toast.makeText(this, "Expense Saved!", Toast.LENGTH_LONG).show()
            checkBudgetAndNotify(category)
            finish()
        }.addOnFailureListener { e ->
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun checkBudgetAndNotify(category: String) {
        val userId = auth.currentUser?.uid ?: return

        db.collection("budgets")
            .whereEqualTo("userId", userId)
            .whereEqualTo("category", category)
            .get()
            .addOnSuccessListener { budgetSnapshot ->
                if (budgetSnapshot.isEmpty) return@addOnSuccessListener

                val budget = budgetSnapshot.documents.first().toObject(Budget::class.java) ?: return@addOnSuccessListener
                val (startDate, endDate) = getStartAndEndOf(budget.period)

                db.collection("expenses")
                    .whereEqualTo("userId", userId)
                    .whereEqualTo("category", category)
                    .whereGreaterThanOrEqualTo("date", startDate)
                    .whereLessThan("date", endDate)
                    .get()
                    .addOnSuccessListener { expenseSnapshot ->
                        val totalExpenses = expenseSnapshot.documents.sumOf { it.getDouble("amount") ?: 0.0 }

                        if (totalExpenses > budget.limit) {
                            sendNotification(category, budget.limit, totalExpenses)
                        }
                    }
            }
    }

    private fun getStartAndEndOf(period: String): Pair<Long, Long> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)

        if (period.equals("Weekly", ignoreCase = true)) {
            calendar.set(Calendar.DAY_OF_WEEK, calendar.firstDayOfWeek)
            val start = calendar.timeInMillis
            calendar.add(Calendar.WEEK_OF_YEAR, 1)
            val end = calendar.timeInMillis
            return Pair(start, end)
        } else if (period.equals("Monthly", ignoreCase = true)) {
            calendar.set(Calendar.DAY_OF_MONTH, 1)
            val start = calendar.timeInMillis
            calendar.add(Calendar.MONTH, 1)
            val end = calendar.timeInMillis
            return Pair(start, end)
        }
        return Pair(0, 0) // Should not happen with valid data
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Budget Alerts"
            val descriptionText = "Notifications for when you exceed your budget"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel("BUDGET_ALERTS", name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun sendNotification(category: String, limit: Double, totalExpenses: Double) {
        val builder = NotificationCompat.Builder(this, "BUDGET_ALERTS")
            .setSmallIcon(R.drawable.ic_budget)
            .setContentTitle("Budget Exceeded for $category")
            .setContentText("You've spent $totalExpenses, which is over your limit of $limit.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }
}
