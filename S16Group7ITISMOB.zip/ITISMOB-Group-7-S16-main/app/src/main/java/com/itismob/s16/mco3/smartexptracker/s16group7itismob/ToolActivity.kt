package com.itismob.s16.mco3.smartexptracker.s16group7itismob

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class ToolActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tool)

        val btnSavings = findViewById<Button>(R.id.btnSavingsTool)
        val btnBudget = findViewById<Button>(R.id.btnBudgetTool)
        val btnBack = findViewById<ImageButton>(R.id.btnBack)

        btnSavings.setOnClickListener {
            startActivity(Intent(this, SavingsChallengeActivity::class.java))
        }

        btnBudget.setOnClickListener {
            startActivity(Intent(this, BudgetBuilderActivity::class.java))
        }

        btnBack.setOnClickListener { finish() }
    }
}