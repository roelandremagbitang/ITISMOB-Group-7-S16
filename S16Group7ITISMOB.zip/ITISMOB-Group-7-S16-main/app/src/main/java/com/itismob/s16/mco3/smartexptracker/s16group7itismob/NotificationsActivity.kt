package com.itismob.s16.mco3.smartexptracker.s16group7itismob

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class NotificationsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)

        // TODO: populate RecyclerView with dummy notifications
    }
}
